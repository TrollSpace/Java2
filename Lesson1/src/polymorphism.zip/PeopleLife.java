/**
 * Created by Misha on 15.08.2018.
 */
public interface PeopleLife {
    public void eat(int countEat);

    public String talk(String idea);

    public boolean sleep();

}
